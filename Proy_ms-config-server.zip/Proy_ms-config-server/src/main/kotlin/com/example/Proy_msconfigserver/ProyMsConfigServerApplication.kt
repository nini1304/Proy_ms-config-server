package com.example.Proy_msconfigserver

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ProyMsConfigServerApplication

fun main(args: Array<String>) {
	runApplication<ProyMsConfigServerApplication>(*args)
}
