package com.example.Proy_msconfigserver

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ProyMsConfigServerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
